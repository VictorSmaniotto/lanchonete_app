import 'package:flutter/material.dart';

class ProdutoPage extends StatelessWidget {
  final int index;
  const ProdutoPage({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset(
          'assets/logotipo.png',
          height: 40,
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            child: Image.asset('assets/hamburger1.jpg'),
          ),
          const SizedBox(
            height: 10,
          ),
          const Padding(
            padding: EdgeInsets.only(left: 15, top: 15),
            child: Text(
              'X-Salada',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(left: 15, top: 15, right: 15),
            child: Text(
              'Pão de hamburguer, humburguer 150grs, maionese especial, catchup, mostarda, tomate',
              style: TextStyle(fontSize: 14),
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(left: 15, top: 15),
            child: Text(
              'R\$ 25,00',
              style: TextStyle(
                  fontSize: 20,
                  color: Color(0xfff24405),
                  fontWeight: FontWeight.bold),
            ),
          )
        ],
      ),
    );
  }
}
