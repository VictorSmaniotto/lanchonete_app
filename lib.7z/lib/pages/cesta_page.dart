import 'package:flutter/material.dart';

class CestaPage extends StatelessWidget {
  const CestaPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Cesta'),
    );
  }
}
